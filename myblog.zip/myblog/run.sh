#!/bin/bash
gunicorn myblog.wsgi:application --bind 0.0.0.0:8000 -D
nginx -c /etc/nginx/myblog.conf -g 'daemon off;'
